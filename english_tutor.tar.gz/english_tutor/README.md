# 유아용 사물 인식 영어 선생님 (Jetson)

카메라로 사물을 보고(YOLO) → 아이가 "이게 뭐야?" 하고 물으면(Whisper) → Gemma가 쉬운 영어 문장과 설명을 만들고 → Piper가 읽어줍니다.

## 파일 구성
| 파일 | 역할 |
|---|---|
| `config.py` | 경로·마이크 번호 등 설정 (환경 변수로 변경 가능) |
| `objects.py` | YOLO 클래스 → (영어 단어, 한국어 이름) 사전. 위험한 물건(칼, 가위)은 제외 |
| `vision.py` | YOLO 탐지, 주 사물 선택, 최근 프레임 기준 안정화 |
| `audio.py` | arecord + whisper.cpp(STT), Piper + aplay(TTS) |
| `tutor.py` | Gemma 수업 생성, 출력 검증/폴백, JSON 캐시 |
| `main.py` | 카메라/음성/수업 3개 스레드 실행 |
| `selftest.py` | 하드웨어 없이 로직 테스트 |

## 준비 (Jetson)
1. 수업에서 만든 `~/vision-llm` 환경(YOLO engine, Gemma GGUF, whisper.cpp, `.piper_venv`)을 그대로 사용합니다.
2. 이 폴더를 `~/vision-llm/english_tutor/` 로 복사
3. 영어 목소리 다운로드: `bash setup_models.sh`
4. 마이크 번호 확인(`arecord -l`) 후 설정: `export MIC_DEVICE=plughw:2,0`

## 실행
```bash
cd ~/vision-llm/english_tutor
python selftest.py          # 먼저 로직 테스트
python main.py --dry-run --no-voice   # 소리/마이크 없이 카메라+Gemma만 확인 ('l' 키)
python main.py              # 전체 실행 (음성 질문 + 'l' 키)
```

## 동작 순서
"컵! 영어로는" → "cup"(천천히 2번) → "This is a cup." → 한국어 쉬운 설명 → "따라 해 볼까요?"

## 설계 포인트
- 영어 단어는 사전에서 확정, Gemma는 예문/설명만 생성 → 오답 방지
- 출력은 `EN:` / `KO:` 두 줄로 고정, 형식이 틀리면 기본 문장으로 대체
- 한 번 만든 수업은 `src/json/lesson_cache.json`에 저장 → 두 번째부터 즉시 응답
- 영어는 영어 Piper 목소리, 한국어는 한국어 목소리로 분리 재생
- TTS 재생 중에는 마이크를 꺼서 자기 소리를 질문으로 오인하지 않음

## 조정 팁
- 아이 말을 못 알아들으면: `RECORD_SECONDS`, `SILENCE_RMS` 조정 (`audio.py`의 `is_silent`가 조용하면 STT를 건너뜀)
- 사물 추가: `objects.py`에 COCO 클래스명 추가
- 메모리 부족 시: `CONTEXT_WINDOW`는 이미 1024로 낮춰둠. Whisper는 CPU 빌드 유지 권장
