"""유아용 사물 인식 영어 선생님 (Jetson)

흐름:  카메라 -> YOLO(보이는 사물 파악)
       아이 음성 "이게 뭐야?" -> Whisper(STT) -> Gemma(영어 단어 + 쉬운 설명) -> Piper(TTS)

스레드 구성 (노트북 06번에서 배운 '기능 분리' 개념을 한 프로그램 안에서 적용)
  - 메인 스레드  : 카메라 + YOLO + 화면 표시   (LLM이 돌아도 영상은 멈추지 않음)
  - 음성 스레드  : 마이크 듣기 -> STT -> 질문이면 요청 발행
  - 수업 스레드  : 요청 받으면 Gemma로 수업 생성 -> TTS로 말하기

실행:
  python main.py              # 음성 질문 + 'l' 키(부모용 수동 트리거)
  python main.py --no-voice   # 마이크 없이 'l' 키로만 테스트
  python main.py --headless   # 모니터 없이 실행 (Ctrl+C로 종료)
"""
import argparse
import os
import queue
import threading
import time

import cv2

import audio
import config as cfg
from objects import KID_OBJECTS
from tutor import Tutor
from vision import Detector, StableTarget, draw, pick_main_object


class App:
    def __init__(self, args):
        self.args = args
        self.stop = threading.Event()
        self.speaking = threading.Event()          # TTS 재생 중에는 마이크를 끈다 (에코 방지)
        self.requests = queue.Queue(maxsize=1)     # 질문이 쌓이지 않도록 1개만
        self.target = StableTarget()
        self.target_lock = threading.Lock()
        self.dry_run = args.dry_run

        print("[1/3] YOLO 로딩...")
        self.detector = Detector()
        print("[2/3] Gemma 로딩... (처음엔 시간이 걸려요)")
        self.tutor = Tutor()
        print("[3/3] 준비 완료!")

    # ------------------------------------------------------------ 출력 ----
    def say_ko(self, text):
        print(f"[선생님-KO] {text}")
        if not self.dry_run:
            self.speaking.set()
            try:
                audio.speak_ko(text)
            finally:
                self.speaking.clear()

    def say_en(self, text, slow=True):
        print(f"[선생님-EN] {text}")
        if not self.dry_run:
            self.speaking.set()
            try:
                audio.speak_en(text, slow)
            finally:
                self.speaking.clear()

    # ------------------------------------------------------- 수업 스레드 --
    def teach_loop(self):
        while not self.stop.is_set():
            try:
                self.requests.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                self.teach_once()
            except Exception as exc:
                print(f"[오류] 수업 중 문제 발생: {exc}")
            time.sleep(0.5)

    def teach_once(self):
        with self.target_lock:
            coco_name = self.target.current()

        if coco_name is None:
            self.say_ko("무슨 물건인지 잘 안 보여요. 카메라에 가까이 보여 주세요!")
            return

        lesson = self.tutor.lesson_for(coco_name)
        if lesson is None:
            self.say_ko("음, 이건 아직 잘 모르겠어요. 다른 물건을 보여 주세요!")
            return

        # 수업 순서: 한국어 이름 -> 영어 단어(천천히 2번) -> 영어 문장 -> 쉬운 설명 -> 따라 하기
        self.say_ko(f"{lesson.ko_name}! 영어로는")
        self.say_en(lesson.word)
        time.sleep(0.4)
        self.say_en(lesson.word)
        self.say_en(lesson.en_sentence)
        self.say_ko(lesson.ko_text)
        self.say_ko("따라 해 볼까요?")

    # ------------------------------------------------------- 음성 스레드 --
    def listen_loop(self):
        while not self.stop.is_set():
            if self.speaking.is_set() or not self.requests.empty():
                time.sleep(0.2)
                continue
            try:
                text = audio.listen_for_question()
            except Exception as exc:
                print(f"[오류] 음성 인식 문제: {exc}")
                time.sleep(1.0)
                continue
            if text:
                print(f"[아이] {text}")
                self.request()

    def request(self):
        try:
            self.requests.put_nowait(True)
        except queue.Full:
            pass  # 이미 수업 요청이 대기 중

    # ------------------------------------------------------ 메인 스레드 --
    def run(self):
        cap = cv2.VideoCapture(cfg.CAMERA_INDEX)
        if not cap.isOpened():
            print("카메라를 열 수 없습니다.")
            return

        threading.Thread(target=self.teach_loop, daemon=True).start()
        if not self.args.no_voice:
            threading.Thread(target=self.listen_loop, daemon=True).start()

        show = (not self.args.headless) and bool(os.environ.get("DISPLAY"))
        print("l : 수동으로 '이게 뭐야?' 요청 | q : 종료")
        if not self.args.dry_run:
            threading.Thread(
                target=lambda: self.say_ko("안녕! 나는 영어 선생님이야. 물건을 보여 주고 이게 뭐야? 하고 물어봐!"),
                daemon=True,
            ).start()

        try:
            while not self.stop.is_set():
                ret, frame = cap.read()
                if not ret:
                    break

                dets = self.detector.detect(frame)
                main = pick_main_object(dets, frame.shape)
                with self.target_lock:
                    self.target.update(main)

                if show:
                    cv2.imshow("English Teacher", draw(frame, dets, main))
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord("q"):
                        break
                    if key == ord("l"):
                        self.request()
                else:
                    time.sleep(0.01)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop.set()
            cap.release()
            cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(description="유아용 사물 인식 영어 선생님")
    parser.add_argument("--no-voice", action="store_true", help="마이크 끄기 ('l' 키로만 질문)")
    parser.add_argument("--headless", action="store_true", help="화면 없이 실행")
    parser.add_argument("--dry-run", action="store_true", help="소리 없이 텍스트만 출력 (디버깅)")
    App(parser.parse_args()).run()


if __name__ == "__main__":
    main()
